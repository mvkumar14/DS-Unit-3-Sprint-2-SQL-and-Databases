Part 1:
[('g', 3, 9), ('v', 5, 7), ('f', 8, 7)]

#1:
[(3,)]

#2:
[(2,)]

#3:
[(2,)]

Part 2:
#1:
[('C�te de Blaye', 263.5), ('Th�ringer Rostbratwurst', 123.79), ('Mishi Kobe Niku', 97), ("Sir Rodney's Marmalade", 81), ('Carnarvon Tigers', 62.5), ('Raclette Courdavault', 55), ('Manjimup Dried Apples', 53), ('Tarte au sucre', 49.3), ('Ipoh Coffee', 46), ('R�ssle Sauerkraut', 45.6)]

#2:
[(37.22222222222222,)]

#3: 
[('Kirkland', 29.0), ('London', 32.5), ('Redmond', 56.0), ('Seattle', 40.0), ('Tacoma', 40.0)]

Part 3:
#1:
[('Exotic Liquids', 'C�te de Blaye', 263.5), ('New Orleans Cajun Delights', 'C�te de Blaye', 263.5), ("Grandma Kelly's Homestead", 'C�te de Blaye', 263.5), ('Tokyo Traders', 'C�te de Blaye', 263.5), ("Cooperativa de Quesos 'Las Cabras'", 'C�te de Blaye', 263.5), ("Mayumi's", 'C�te de Blaye', 263.5), ('Pavlova, Ltd.', 'C�te de Blaye', 263.5), ('Specialty Biscuits, Ltd.', 'C�te de Blaye', 263.5), ('PB Kn�ckebr�d AB', 'C�te de Blaye', 263.5), ('Refrescos Americanas LTDA', 'C�te de Blaye', 263.5)]

#2:
[('Confections', 13)]

#3
[('Robert', 10)]
